<?php  ?>
<html>
<head>
</head>
<body>
<form action="udate.php" method="post">
<label>Enter Roll NO :</label>
<input  name="name" type="text"/>
<br><br>
<input type="submit"/>
</form>
</body>
</html>





















